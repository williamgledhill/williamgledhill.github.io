import React from "react";
import { Link } from "react-router-dom";

const CenteredContent = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black text-white p-4">
      <div className="text-center space-y-6 max-w-2xl">
        <h1 className="text-4xl font-geist">Hello there.</h1>
        
        <p className="text-xl font-geist">
          This is my website. I hope you like it.
        </p>
        
        <p className="text-xl font-geist">
          You can find my book list <Link to="/books" className="underline">here</Link>
        </p>
        
        <p className="text-xl font-geist">
          Or contact me <a href="mailto:williamswgledhill@gmail.com" className="underline">here</a>
        </p>
      </div>
    </div>
  );
};

export default CenteredContent;