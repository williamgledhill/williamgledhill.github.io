import { Link } from "react-router-dom";

const Books = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white p-4">
      <div className="text-center space-y-6 max-w-2xl">
        <Link to="/" className="flex items-center text-xl font-geist mb-8 hover:opacity-80">
          ← Back
        </Link>
        
        <h1 className="text-4xl font-geist mb-12">Book list</h1>
        
        <p className="text-xl font-geist">
          Sorry, no books yet.
        </p>
      </div>
    </div>
  );
};

export default Books;