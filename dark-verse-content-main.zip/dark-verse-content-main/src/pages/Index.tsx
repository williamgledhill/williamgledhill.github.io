import CenteredContent from "@/components/CenteredContent";

const Index = () => {
  return <CenteredContent />;
};

export default Index;